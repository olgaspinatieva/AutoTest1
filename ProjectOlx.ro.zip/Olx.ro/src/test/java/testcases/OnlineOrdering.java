package testcases;
import com.google.common.io.Files;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import base.Base;
import utilities.ReadCredentialsXlsxFile;


	public class OnlineOrdering extends Base {
		
		@Test(priority=1, description="Check Title1, Logo and accept_cookies button", dataProviderClass=ReadCredentialsXlsxFile.class)
		public void checkTitle() {
		
			String expectedTitle1 = "Anunturi Gratuite - Peste 4 milioane anunturi - OLX.ro"; //check title1, hard assertion
			String actualTitle1 = driver.getTitle();
			Assert.assertEquals(actualTitle1, expectedTitle1);
			System.out.println("The page title has been checked");
			
			System.out.println("the current address is: " + driver.getCurrentUrl()); //getCurrentUrl method
			System.out.println("LOGO has the following size: " + driver.findElement(By.cssSelector(loc.getProperty("logo_button"))).getSize()); //method getSize
			System.out.println("LOGO has the following location: " + driver.findElement(By.cssSelector(loc.getProperty("logo_button"))).getLocation()); //method getLocation
			System.out.println("The button 'accept_cookies' is displayed: " + driver.findElement(By.xpath(loc.getProperty("accept_button"))).isDisplayed()); //is displayed method
			System.out.println("The 'accept_cookies' button has the following text: " + driver.findElement(By.xpath(loc.getProperty("accept_button"))).getText()); // getText method
			
			SoftAssert softAssert1 = new SoftAssert(); //check button's value, soft assertion
			String expectedAcceptButtonValue = "Accept";
			String actualAcceptButtonValue = driver.findElement(By.xpath(loc.getProperty("accept_button"))).getText();
			Assert.assertEquals(actualAcceptButtonValue, expectedAcceptButtonValue);
			softAssert1.assertAll();
			System.out.println("Soft assertion1");

		}
		
		@Test(priority=2, description="Check text input in ProductSearch placeholder and Informatii Ordin in Footer Section", dataProvider = "searchData")
		
			public void providerDataTest (String product, String city) throws InterruptedException, IOException {

			driver.findElement(By.xpath(loc.getProperty("accept_button"))).click(); //allow cookies
			Thread.sleep(2000);
			
			driver.findElement(By.id(loc.getProperty("search_input"))).click(); 
			driver.findElement(By.id(loc.getProperty("search_input"))).sendKeys(product); //insert product from dataProvider in this Class
			Thread.sleep(4000);
			driver.findElement(By.id(loc.getProperty("location_input"))).click();
			driver.findElement(By.id(loc.getProperty("location_input"))).sendKeys(city); //insert city from dataProvider in this Class
			
			Thread.sleep(3000);
			
			File screenshotFile1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE); //take screenshot
			Files.copy(screenshotFile1, new File(".//screenshot/" + "Screenshot1" + ".png")); //save screenshot file
			
			Thread.sleep(3000);
			
			WebElement informatii = driver.findElement(By.xpath(loc.getProperty("informatii_ordin")));
			Actions scrollAction = new Actions(driver);  //scrolling till footer section 
			scrollAction.moveToElement(informatii);
			scrollAction.perform();
			
			Thread.sleep(4000);
			String windowHandle = driver.getWindowHandle(); // getWindowHandle method
			
			driver.findElement(By.xpath(loc.getProperty("informatii_ordin"))).click();	
			Thread.sleep(10000);
			
			driver.switchTo().window(windowHandle); // switch to method	
			Thread.sleep(4000);
			
			driver.close();
			
					}
		
			@DataProvider(name="searchData") 
			public Object[][] providerDataSet() {
				
				return new Object[][] {
					
					{"Robot de aspirare Roborock Q7 MAX+ Q7MP02-00", "Brasov"},
					
				};		
			}
		
		@Test(priority=3, description="Sign In and Select product", dataProviderClass=ReadCredentialsXlsxFile.class, dataProvider = "credentialsData")
			public static void OrderTest(String email, String password, String productName1) throws InterruptedException, IOException   {
			
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15)); //implicit wait

			driver.findElement(By.xpath(loc.getProperty("accept_button"))).click(); //allow cookies
			Thread.sleep(2000);
			
			driver.findElement(By.xpath(loc.getProperty("contulTau_button"))).click(); //click on 'Contul Tau'
			Thread.sleep(2000);
				
			driver.findElement(By.xpath(loc.getProperty("email"))).sendKeys(email); // 'Login' Section: email
			System.out.println("Email has been entered");
			Thread.sleep(3000);
			driver.findElement(By.xpath(loc.getProperty("password"))).sendKeys(password); //'Login' Section: password
			System.out.println("Password has been entered");
			Thread.sleep(3000);
			driver.findElement(By.xpath(loc.getProperty("login_button"))).click(); //click on 'Login' button
			System.out.println("Button Login has been clicked");
				
			Reporter.log("Log: User has been logged in"); //report
			System.out.println("User has been logged in");
			Thread.sleep(5000);
			driver.findElement(By.cssSelector(loc.getProperty("logo_button"))).click();	//click on 'Logo' button to return to main page
			Thread.sleep(6000);	
				
			driver.findElement(By.id(loc.getProperty("search_input"))).click();
			Thread.sleep(6000);
			
			driver.findElement(By.cssSelector(loc.getProperty("cautare_button"))).click(); //click on 'Cautare' button 
			driver.findElement(By.id(loc.getProperty("search_input"))).sendKeys(productName1); // productName1 from the external excel document credentials.xls
			
			Thread.sleep(5000);
			
			WebElement contulTau= driver.findElement(By.xpath(loc.getProperty("profil_option"))); //hover over 'Contul Tau'
			Actions hoverActions = new Actions(driver);
			hoverActions.moveToElement(contulTau).perform();
			Thread.sleep(4000);
				
			File screenshotFile2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE); //take screenshot
			Files.copy(screenshotFile2, new File(".//screenshot/" + "Screenshot2" + ".png")); //save screenshot file
			
			Thread.sleep(4000);
			
			/*
			
			driver.findElement(By.name(loc.getProperty("cautare_button"))).click();
			Thread.sleep(4000);
			
			driver.findElement(By.id(loc.getProperty("cuLivrare_checkbox"))).click(); // select 'Cu livrare" option in checkbox
			Thread.sleep(5000);
			
			driver.findElement(By.id(loc.getProperty("search_input"))).click();
			
			Thread.sleep(6000);
			
			driver.findElement(By.cssSelector(loc.getProperty("oferte_input"))).click(); //by locator with two attributes (click on "Oferte pentru tine" placeholder)
			Thread.sleep(2000);
			
			driver.findElement(By.cssSelector(loc.getProperty("select_option"))).click(); //by locator with two attributes (select "Noi" option)
			Thread.sleep(6000);
		
			driver.findElement(By.cssSelector(loc.getProperty("salveaza_cautare"))).click(); //other attribute (click on "Salveaza cautare" button)
			Thread.sleep(6000);
	

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20)); //explicit wait
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("cumpara_button"))).click();
				
			driver.findElement(By.cssSelector("div[data-testid='listing-grid'] a")).click(); //first child
			Thread.sleep(3000);
				
			*/
							
		}
		
		
			@Test(enabled=false)  //skip test
			public void skipTest() {
			System.out.println("the current source is: " + driver.getPageSource());		
		}
		}
		
	