package base;

import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeMethod;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Base {
	public static WebDriver driver; //declaram webdriver pentru a-l putea mosteni si utiliza in classa MainPage
	public static Properties prop = new Properties(); //declaram properties pentru a putea accesa fisierul config.properties 
	public static Properties loc = new Properties(); // declaram properties pentru a putea accesa fisierul locators.properties
	public static FileReader fr1; // declaram FileReader pentru a-l putea utiliza in r.29
	public static FileReader fr2; // declaram FileReader pentru a-l putea utiliza in r.30

	@BeforeMethod
	public void SetUp() throws IOException {
		
		if(driver==null) {  // if WebDriver doesn't get any value in r.16 a condition from r.29 and r.30 is executed 
			//FileReader fr1 = new FileReader("C:\\\\Users\\\\Olia\\\\AutomationWorkspace\\\\Olx.ro\\\\src\\\\test\\\\resources\\\\configfiles\\\\config.properties");
			
			FileReader fr1 = new FileReader(System.getProperty("user.dir")+"\\src\\\\test\\\\resources\\\\configfiles\\\\config.properties"); //relative path		
			FileReader fr2 = new FileReader("C:\\\\Users\\\\Olia\\\\AutomationWorkspace\\\\Olx.ro\\\\src\\\\test\\\\resources\\\\configfiles\\\\locators.properties"); //absolute path
			
			prop.load(fr1);
			loc.load(fr2);

			
		} if(prop.getProperty("browser").equalsIgnoreCase("chrome")) { // in cazul care in fisierul config.properties va gasi valoarea chrome pentru browser
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.get(prop.getProperty("testurl"));
			driver.manage().window().maximize();	

		} else if(prop.getProperty("browser").equalsIgnoreCase("edge")) { // in cazul care in fisierul config.properties va gasi valoarea firefox pentru browser
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
			driver.get(prop.getProperty("testurl"));
			driver.manage().window().maximize();

		}

	}

	@AfterMethod
	public void tearDownUp() {
		
		driver.quit();
		System.out.println("Browser has been closed");

	}

}
