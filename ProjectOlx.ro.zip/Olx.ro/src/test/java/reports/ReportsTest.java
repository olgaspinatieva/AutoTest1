package reports;

import org.testng.Reporter;
import org.testng.annotations.Test;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class ReportsTest {
	
	@Test
	public void reporterTest1() {
		Reporter.log("This is Test1 log");
		System.out.println("This is Test 1");
	}
	
	@Test
	public void reporterTest2() {
		Reporter.log("This is Test2 log");
		System.out.println("This is Test 2");
	}

}
