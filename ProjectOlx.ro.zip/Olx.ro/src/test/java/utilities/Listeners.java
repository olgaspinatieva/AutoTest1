package utilities;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

	
	public class Listeners implements ITestListener {
		public void onTestStart(ITestResult result) {
			System.out.println("Test case is starting");
			
		}
		
		public void onTestSuccess(ITestResult result) {
			
			System.out.println("Test case is onTest");
		}
		
		public void onTestFailure(ITestResult result) {
			System.out.println("Test case is failed");
		}
		
		public void onTestSkipped(ITestResult result) {
		}
		
		public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
			// TODO Auto-generated method stub //screenshot
		}
		
		public void onTestFailedWithTimeout(ITestResult result) {
			// TODO Auto-generated method stub
		}
		
		public void onStart(ITestContext context) {
			// TODO Auto-generated method stub
		}
		
		public void onFinish(ITestContext context) {
			System.out.println("Test case is finished");
		}
	
	
}

